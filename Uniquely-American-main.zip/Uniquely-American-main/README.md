# Public Safety in America

Team members:
Seth Feaser,Hinal Patel,Sruthi Padisetty,Anusha Gani

The files in the [public](/public) directory are deployed to: https://cse442.pages.cs.washington.edu/24wi/final-project/Uniquely-American/
